import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, setPersistence, browserLocalPersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID
};

function isLikelyValidApiKey(key?: string): boolean {
  if (!key) return false;
  // Typical Firebase Web API keys start with AIza and are ~39 chars
  return key.startsWith('AIza') && key.length >= 30;
}

function hasRequiredClientConfig(): boolean {
  return Boolean(
    isLikelyValidApiKey(firebaseConfig.apiKey) &&
      firebaseConfig.authDomain &&
      firebaseConfig.projectId &&
      firebaseConfig.appId
  );
}

// Initialize Firebase
const isBrowser = typeof window !== 'undefined';

let app: ReturnType<typeof getApp> | null = null;
let auth: any = null;
let db: ReturnType<typeof getFirestore> | null = null;
let storage: ReturnType<typeof getStorage> | null = null;

try {
  if (hasRequiredClientConfig()) {
    app = getApps().length ? getApp() : initializeApp(firebaseConfig);
    db = getFirestore(app);
    storage = getStorage(app);
    if (isBrowser) {
      auth = getAuth(app);
      setPersistence(auth, browserLocalPersistence).catch((error) => {
        console.error('Error setting auth persistence:', error);
      });
    }
  } else {
    // Log diagnostics once in dev
    if (process.env.NODE_ENV !== 'production') {
      // eslint-disable-next-line no-console
      console.warn('[Firebase] Skipping initialization due to missing/invalid config', {
        hasApiKey: Boolean(firebaseConfig.apiKey),
        apiKeyLooksValid: isLikelyValidApiKey(firebaseConfig.apiKey),
        projectId: firebaseConfig.projectId,
        authDomain: firebaseConfig.authDomain,
        appIdPresent: Boolean(firebaseConfig.appId)
      });
    }
  }
} catch (err) {
  console.error('[Firebase] Initialization error:', err);
}

export { app, auth, db, storage };
